create database apartamento;
use apartamento;


create table cep (
CEP int primary key,
logradouro varchar(45),
numero int,
bairro varchar(45),
cidade varchar(45)
);

insert into cep values
	(03204900,'Rua Alves',190,'Vila Madalena','São Paulo'),
    (03207030, 'Rua das Bandeiras',241,'Vila Mariana','São Paulo');
    

	
create table condominio(
idCond int primary key auto_increment,
nomeCond varchar(45),
descricao varchar(45),
fkcep int,
foreign key (fkcep) references cep(CEP)
);

insert into condominio (nomeCond,descricao,fkcep) values
	('Vila Flora','Apts 4 quartos, suite e piscina',03204900),
    ('Albatroz','Apts 2 quartos, piscina e salão de jogos',03207030);

create table pessoa	(
idPessoa int primary key auto_increment,
nomePessoa varchar(45),
telefoneCelular varchar(30),
telefoneRes varchar(30)
)auto_increment=100;

insert into pessoa (nomePessoa,telefoneCelular,telefoneRes) values

('Artur Silva','980406070','1149586478'),
('Maria Silva','987590678','1149586478'),
('Julia Gomes','983749585','1198484030'),
('Marcos Souza','94048383','1185903004'),
('João Silva','940383049','1149586478')
;



create table unidade (
idUnid int primary key auto_increment,
apartamento int,
andar int,
fkCond int,
fkpessoa int,
foreign key (fkCond) references condominio(idCond),
foreign key (fkpessoa) references pessoa(idpessoa)
)auto_increment=1000;

select * from pessoa;
insert into unidade (apartamento, andar, fkCond, fkpessoa) values
(46,4,1,100),
(32,3,1,null),
(10,1,2,102);

select * from unidade;


create table possui (
fkpessoa int,
fkUnid int,
porcentagem int,
foreign key (fkpessoa) references pessoa(idpessoa),
foreign key (fkUnid) references unidade(idUnid),
primary key (fkpessoa, fkunid)
);

insert into possui values
(101,1000,50),
(102,1002,100),
(103,1001,100),
(104,1000,50);


select * from possui, pessoa,unidade where possui.fkpessoa=idpessoa and fkUnid = idUnid;

select 
		cep.*,
		cond.nomeCond, 
		cond.descricao, 
		pessoa.nomepessoa as 'Nome dos proprietários', 
		unidade.apartamento, 
		unidade.andar, 
		possui.porcentagem
	from
		cep,
		condominio as cond,
		pessoa,
		unidade,
		possui
   where
		cep.CEP=fkcep
	and
		idcond=fkcond
	and 
		pessoa.idpessoa=possui.fkpessoa
	and
		idunid=possui.fkunid;

    select 
		cep.*,
		cond.nomeCond, 
		cond.descricao, 
		pessoa.nomepessoa as 'Nome dos proprietários', 
		unidade.apartamento, 
		unidade.andar, 
		unidade.fkpessoa ,
		nomepessoa 'Aluga o apt',
		possui.porcentagem
	from
		cep,
		condominio as cond,
		pessoa,
		unidade,
		possui
   where
		cep.CEP=fkcep
	and
		idcond=fkcond
	and 
		idpessoa=possui.fkpessoa
	and
		idunid=possui.fkunid
	and 
		idpessoa=unidade.fkpessoa;
        
	select 
		cep.*,
		cond.nomeCond, 
		cond.descricao, 
		pessoa.nomepessoa as 'Nome dos proprietários', 
		unidade.apartamento, 
		unidade.andar, 
		unidade.fkpessoa ,
		responsavel.nomepessoa as 'Inquilino',
		possui.porcentagem
	from
		cep,
		condominio as cond,
		pessoa,
		unidade,
		possui,
		pessoa as responsavel
   where
		cep.CEP=fkcep
	and
		idcond=fkcond
	and 
		pessoa.idpessoa=possui.fkpessoa
	and
		idunid=possui.fkunid
	and 
		responsavel.idpessoa=unidade.fkpessoa;

        insert into pessoa values
        (105,'Bianca Nunes','93123745','10293845');
	
    select * from unidade;
 
 update unidade set fkpessoa=105 where idUnid=1001